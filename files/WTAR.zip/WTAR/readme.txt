
This code gave the detailed implementation of ``Tensor Recovery with Weighted Tensor Average Rank''.
 
demo_TRWTANN.m  TRWTANN on the case of guassian denoising for delta=5 and delta=15
demo_TRWTARlp.m  TRWTARlp on the case of guassian denoising for delta=5 and delta=15


The code contains:
The `data' folder contains color images including  House, Lena, Peppers, F16, Baboon, and the 1?3 th and 12th images from the Kadak PhotoCD [1]
 
The 'e LibADMM toolbox' folder contains some necessary functions for tensor algebra.

WTAR_ADMM.m        Solve the following optimization problem using ADMM method  argmin_{A,E} lambda_1 \sum_k alpha_k||A^{T_k}||^g_{*,a} + beta* ||S||_g
+||D-A-S||_F^2,  where D,A,S are tensors.  

[1] https://webpages.tuni.fi/foi/GCF-BM3D/index.html
[2] https://github.com/canyilu/LibADMM-toolbox

Any comments or questions, please contact  Xiaoqin Zhang (zhangxiaoqinnan@gmail.com)



