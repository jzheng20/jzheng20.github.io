clear all;clc;

% %  Guassian denoising for case of delta=5
% delta=5;
% par=[300;inf];
% Out_dir='5_TRWTANN';


%  Guassian denoising for case of delta=15
delta=15;
par=[800;inf];
Out_dir='15_TRWTANN';


In_dir='data'; 
fpath=fullfile(In_dir,'*.png');
im_dir=dir(fpath);
im_num=length(im_dir);
cnt=0;

fn_tex=strcat(Out_dir,'PSNR_SSIM.txt');
fd_txt=fopen(fullfile(Out_dir,fn_tex),'wt');
fprintf(fd_txt, 'delta=%d : \n', delta);
for i=1:im_num

    X  =double(imread(fullfile(In_dir,im_dir(i).name)));
    [m,n,h]=size(X);
    noisedX=X +delta*randn(m,n,h);
    [L,~,~] =WTAR_ADMM(noisedX, par,@soft,1, [1,1,1]);
    psnr(i)=csnr(X,L,0,0);
    ssim(i)  =  cal_ssim(X,L, 0, 0 );
    fname            =   strcat( Out_dir, im_dir(i).name);
    imwrite(uint8(L), fullfile(Out_dir, fname));
    fprintf(fd_txt, '%s:  PSNR = %2.2f, SSIM= %2.4f \n', im_dir(i).name, psnr(i), ssim(i));
end

fprintf(fd_txt, '\n Average :  PSNR = %2.2f, SSIM= %2.4f', mean(psnr),mean(ssim));
fclose(fd_txt);