Please cite the following reference if you use this code. 

[1] X. Zhang, J. Zheng, D. Wang, G. Tang, Z. Zhou and Z. Lin, "Structured Sparsity Optimization With Non-Convex Surrogates of  ℓ2,0-Norm: A Unified Algorithmic Framework," 
in IEEE Transactions on Pattern Analysis and Machine Intelligence, vol. 45, no. 5, pp. 6386-6402, 1 May 2023, doi: 10.1109/TPAMI.2022.3213716.


If you encounter any issues with this code, please feel free to contact me (Jingjing Zheng, jjzheng233@gmail.com).